import { supabase } from "@/lib/supabase"
import LoginForm from "@/components/LoginForm"

export default async function Home() {
  const { data: { user } } = await supabase.auth.getUser()

  return (
    <main className="p-8">
      {user ? (
        <div>
          <p>Hallo, {user.email}!</p>
          <form action="/logout" method="post">
            <button className="mt-4 bg-red-500 text-white px-4 py-2">Logout</button>
          </form>
        </div>
      ) : (
        <LoginForm />
      )}
    </main>
  )
}
